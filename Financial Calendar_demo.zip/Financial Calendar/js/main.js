$(document).ready(function(){

	console.log(window.performance.timing.navigationStart);

	var fyCalData = [{
		"year": "2017-18",
		"Q1": {
			"val": "072017",
			"monthMap": [{
				"month": "July",
				"monYearVal": "072017",
				"val": "07"
			}, {
				"month": "",
				"monYearVal": "",
				"val": ""
			}, {
				"month": "",
				"monYearVal": "",
				"val": ""
			}]
		},
		"Q2": {
			"val": "092017",
			"monthMap": [{
				"month": "Aug",
				"monYearVal": "082017",
				"val": "08"
			}, {
				"month": "Sep",
				"monYearVal": "092017",
				"val": "09"
			}, {
				"month": "",
				"monYearVal": "",
				"val": ""
			}]
		},
		"Q3": {
			"val": "122017",
			"monthMap": [{
				"month": "Oct",
				"monYearVal": "102017",
				"val": "10"
			}, {
				"month": "Nov",
				"monYearVal": "112017",
				"val": "11"
			}, {
				"month": "Dec",
				"monYearVal": "122017",
				"val": "12"
			}]
		},
		"Q4": {
			"val": "032018",
			"monthMap": [{
				"month": "Jan",
				"monYearVal": "012018",
				"val": "01"
			}, {
				"month": "Feb",
				"monYearVal": "022018",
				"val": "02"
			}, {
				"month": "Mar",
				"monYearVal": "032018",
				"val": "03"
			}]
		}
	},
	{
		"year": "2018-19",
		"Q1": {
			"val": "062018",
			"monthMap": [{
				"month": "Apr",
				"monYearVal": "042018",
				"val": "04"
			}, {
				"month": "May",
				"monYearVal": "052018",
				"val": "05"
			}, {
				"month": "Jun",
				"monYearVal": "062018",
				"val": "06"
			}]
		},
		"Q2": {
			"val": "092018",
			"monthMap": [{
				"month": "July",
				"monYearVal": "072018",
				"val": "07"
			}, {
				"month": "Aug",
				"monYearVal": "082018",
				"val": "08"
			}, {
				"month": "Sep",
				"monYearVal": "092018",
				"val": "09"
			}]
		},
		"Q3": {
			"val": "122018",
			"monthMap": [{
				"month": "Oct",
				"monYearVal": "102018",
				"val": "10"
			}, {
				"month": "Nov",
				"monYearVal": "112018",
				"val": "11"
			}, {
				"month": "Dec",
				"monYearVal": "122018",
				"val": "12"
			}]
		},
		"Q4": {
			"val": "032019",
			"monthMap": [{
				"month": "Jan",
				"monYearVal": "012019",
				"val": "01"
			}, {
				"month": "Feb",
				"monYearVal": "022019",
				"val": "02"
			}, {
				"month": "Mar",
				"monYearVal": "032019",
				"val": "03"
			}]
		}
	},
	{
		"year": "2019-20",
		"Q1": {
			"val": "062019",
			"monthMap": [{
				"month": "Apr",
				"monYearVal": "042019",
				"val": "04"
			}, {
				"month": "May",
				"monYearVal": "052019",
				"val": "05"
			}, {
				"month": "Jun",
				"monYearVal": "062019",
				"val": "06"
			}]
		},
		"Q2": {
			"val": "092019",
			"monthMap": [{
				"month": "July",
				"monYearVal": "072019",
				"val": "07"
			}, {
				"month": "Aug",
				"monYearVal": "082019",
				"val": "08"
			}, {
				"month": "Sep",
				"monYearVal": "092019",
				"val": "09"
			}]
		},
		"Q3": {
			"val": "122019",
			"monthMap": [{
				"month": "Oct",
				"monYearVal": "102019",
				"val": "10"
			}, {
				"month": "Nov",
				"monYearVal": "112019",
				"val": "11"
			}, {
				"month": "Dec",
				"monYearVal": "122019",
				"val": "12"
			}]
		},
		"Q4": {
			"val": "032020",
			"monthMap": [{
				"month": "Jan",
				"monYearVal": "012020",
				"val": "01"
			}, {
				"month": "Feb",
				"monYearVal": "022020",
				"val": "02"
			}, {
				"month": "Mar",
				"monYearVal": "032020",
				"val": "03"
			}]
		}
	},
	{
		"year": "2020-21",
		"Q1": {
			"val": "062020",
			"monthMap": [{
				"month": "Apr",
				"monYearVal": "042020",
				"val": "04"
			}, {
				"month": "May",
				"monYearVal": "052020",
				"val": "05"
			}, {
				"month": "Jun",
				"monYearVal": "062020",
				"val": "06"
			}]
		},
		"Q2": {
			"val": "092020",
			"monthMap": [{
				"month": "July",
				"monYearVal": "072020",
				"val": "07"
			}, {
				"month": "Aug",
				"monYearVal": "082020",
				"val": "08"
			}, {
				"month": "Sep",
				"monYearVal": "092020",
				"val": "09"
			}]
		},
		"Q3": {
			"val": "122020",
			"monthMap": [{
				"month": "Oct",
				"monYearVal": "102020",
				"val": "10"
			}, {
				"month": "Nov",
				"monYearVal": "112020",
				"val": "11"
			}, {
				"month": "Dec",
				"monYearVal": "122020",
				"val": "12"
			}]
		},
		"Q4": {
			"val": "032021",
			"monthMap": [{
				"month": "Jan",
				"monYearVal": "012021",
				"val": "01"
			}, {
				"month": "Feb",
				"monYearVal": "022021",
				"val": "02"
			}, {
				"month": "Mar",
				"monYearVal": "032021",
				"val": "03"
			}]
		}
	},
	{
		"year": "2021-22",
		"Q1": {
			"val": "062021",
			"monthMap": [{
				"month": "Apr",
				"monYearVal": "042021",
				"val": "04"
			}, {
				"month": "May",
				"monYearVal": "052021",
				"val": "05"
			}, {
				"month": "Jun",
				"monYearVal": "062021",
				"val": "06"
			}]
		},
		"Q2": {
			"val": "092021",
			"monthMap": [{
				"month": "July",
				"monYearVal": "072021",
				"val": "07"
			}, {
				"month": "Aug",
				"monYearVal": "082021",
				"val": "08"
			}, {
				"month": "Sep",
				"monYearVal": "092021",
				"val": "09"
			}]
		},
		"Q3": {
			"val": "122021",
			"monthMap": [{
				"month": "Oct",
				"monYearVal": "102021",
				"val": "10"
			}, {
				"month": "Nov",
				"monYearVal": "112021",
				"val": "11"
			}, {
				"month": "Dec",
				"monYearVal": "122021",
				"val": "12"
			}]
		},
		"Q4": {
			"val": "032022",
			"monthMap": [{
				"month": "Jan",
				"monYearVal": "012022",
				"val": "01"
			}, {
				"month": "Feb",
				"monYearVal": "022022",
				"val": "02"
			}, {
				"month": "Mar",
				"monYearVal": "032022",
				"val": "03"
			}]
		}
	}
]


var fy;

	$('.fy_calendar').financialCalendar({
		fyData: fyCalData,
		selectedYear: '2017-18',
		selectedMonth: '01',
		calendarType: 'Q',
		getMonth: function(e){
			console.log(e);
		},
		getYear: function(y){
			fy = y;
			console.log(y);
		},
		setQtr: function(){

			if(fy =='2017-18'){
				return 'Q';
			} else if(fy =='2018-19'){
				return 'M';
			} else{
				return 'M';
			}

		},
		getDefaultDate: function(q){
			console.log(q);
		}
	});
})