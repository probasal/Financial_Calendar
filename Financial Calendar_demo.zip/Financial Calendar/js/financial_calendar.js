 (function($){
     $.fn.financialCalendar = function (options) {
         
         // Default settings:
         $.fn.financialCalendar.defaults = {
             fyData: null,
             selectedYear: null,
             selectedMonth: null,
             calendarType: 'M',
             getMonth: function(){},
             getYear: function(){},
             setQtr: function(qtr){
                return qtr;
             },
             getDefaultDate: function(){}
         };
         
         var settings = $.extend({}, $.fn.financialCalendar.defaults, options);
 
         return this.each(function(){

             var $this = $(this);
             var fyJsonData = settings.fyData;

             var dt = new Date();

            // Set Current Financial Year
            if(!settings.selectedYear){
                if(dt.getMonth() <=2){
                    settings.selectedYear = (dt.getFullYear()-1) + "-" + (parseInt((dt.getFullYear()-1).toString().slice(2))+1);
                }else{
                    settings.selectedYear = dt.getFullYear() + "-" + (parseInt(dt.getFullYear().toString().slice(2))+1);
                }
            }

            //set Curent month
            if(!settings.selectedMonth){
                 settings.selectedMonth = ('0' + (dt.getMonth()+1)).slice(-2);   
            }

            if ( $.isFunction( settings.complete ) ) {
                settings.complete.call( this );
            }

            var _yearOptions = "";
            var _monthOptions = "";

            if(!fyJsonData){
                alert('Calendar Json Data Not Found!');
            }else{
                _yearLists();
                _getfyCalendar(settings.selectedYear);
            }

            function _yearLists(){
                for(var i = 0; i < fyJsonData.length; i++){
                     _yearOptions += '<option value="' + fyJsonData[i].year + '">'+ fyJsonData[i].year + '</option>';
                }
            }

            function monthLists(year){
                var jsonObj ="";
                for(var i = 0; i < fyJsonData.length; i++){
                   if(fyJsonData[i].year==year){
                    jsonObj = fyJsonData[i];
                    break;
                   }
               }

                for(var i = 1; i <= 4; i++){
                    var key= "Q"+i;
                    _monthOptions+= '<tr>';    
                    _monthOptions+= '<td><a class="fy-month q-label" data-fmvalue="'+ jsonObj[key].val +'"><span>'+ key +'</span></a></td>';
                    var monthObj = jsonObj[key];
                    for(var j=0; j<monthObj.monthMap.length; j++){
                        _monthOptions+= '<td><a class="fy-month" data-fmvalue="'+ monthObj.monthMap[j].monYearVal +'" data-mval="'+ monthObj.monthMap[j].val +'" ><span>' + monthObj.monthMap[j].month + '</span></a></td>';
                    }
                    _monthOptions+= '</tr>';                    
               }

            };

            function _getfyCalendar(year){
                monthLists(year);
            }

            var _markup = '<div class="fy-calendar-container-ui"> <div class="fy-calendar-header"> <select>'+ _yearOptions + '</select></div><table class="fy-ui-calendar">'+ _monthOptions + '</table></div>';

            if(fyJsonData){
                $this.html(_markup);

            }

            _disablMonthBtn();

            function _disablMonthBtn(){
                for(var i = 0; i < $this.find('.fy-month').length; i++){
                    if($this.find('.fy-month span').eq(i).html() == ''){
                        $this.find('.fy-month').eq(i).addClass('fy-disabled');
                   }
                }
            }

            _selectedYear();

            function _selectedYear(){
                $this.find('select').val(settings.selectedYear);
            }

            _calendarType(settings.calendarType);

            function _calendarType(ct){

                if(ct == 'M'){
                    $this.find(".fy-ui-calendar tr td:nth-child(1)").find('a').addClass('fy-disabled-bg');
                }else if(ct == 'Q'){
                    $this.find(".fy-ui-calendar tr td:nth-child(n+2)").find('a').addClass('fy-disabled-bg');
                }else{
                    alert('Please use correct calendar Type!');
                    $('.fy_calendar').html("Use correct Calendar Type 'M' or 'Q'");
                }
            }


            function quarterSelection(){
                if(settings.calendarType == 'Q'){
                    $('.fy-month').removeClass('fy-month-select');
                    $('.fy-ui-calendar tr').removeClass('q-select');
                    $(this).find('td').eq(0).find('a').addClass('fy-month-select');
                    $(this).addClass('q-select');
                }
            }

            var _monthtd = $this.find('.fy-ui-calendar');
            var _selectYear = $this.find('select');

             _selectYear.on('change', function(){
                 _monthOptions = "";
                 _getfyCalendar(this.value);
                 $('.fy-ui-calendar').html(_monthOptions);
                 _disablMonthBtn();
                 getFyValue(this.value);
                 settings.calendarType = settings.setQtr();
                 _calendarType(settings.calendarType);   
                 futureDisabledMonth(this.value);
             })

             _monthtd.on('click','tr',function(){
                 if(settings.calendarType == 'Q'){
                    quarterSelection.call(this);
                    var month = $(this).find('td').eq(0).find('a').data("fmvalue");
                    getMonthValue(month);
                 }
             });

             _monthtd.on('click','a',function(e){
                e.stopPropagation();
                $('.fy-month').removeClass('fy-month-select');
                $(this).addClass('fy-month-select');
                $('.fy-ui-calendar tr').removeClass('q-select');

                if($(this).hasClass('q-label')){
                    $(this).closest('tr').addClass('q-select');
                }else{
                   // $(this).find('tr').removeClass('q-select');
                }

                var month = $(this).data("fmvalue");
                getMonthValue(month);
             })


             var curentYear = dt.getFullYear() + "-" + (parseInt(dt.getFullYear().toString().slice(2))+1);


             selectedMonth(settings.selectedMonth);

             // selected Month based on Monthly
             function selectedMonth(mt){
                $( ".fy-ui-calendar a" ).each(function( i ) {
                    if(settings.calendarType == "M"){
                        if ( $(this).data("mval") == mt) {
                            $(this).addClass('fy-month-select');
                        }
                    }else if(settings.calendarType == "Q"){
                        if ( $(this).data("mval") == mt) {
                            $(this).closest('tr').addClass('q-select');
                            $(this).closest('tr').find('td:nth-child(1)').find('a').addClass('fy-month-select');
                        }
                    }
                  });                
             }

             futureDisabledMonth(settings.selectedYear);

             function futureDisabledMonth(cy){
                $( ".fy-ui-calendar a" ).each(function( i ) {       
                    if(settings.calendarType == "M"){                 
                        if( curentYear == cy && $(this).data("mval") == (dt.getMonth()+1)){
                            for(var j = i+1; j<=15; j++){
                                $('.fy-ui-calendar a').eq(j).addClass('fy-disabled-bg');
                            }
                        }
                    }else if(settings.calendarType == "Q"){
                        if( curentYear == cy && $(this).data("mval") == (dt.getMonth()+1)){

                            var qindex = $('.fy-ui-calendar a').eq(i).closest('tr').index();

                            for(var k = qindex+1; k<=3; k++){
                                $('.fy-ui-calendar tr').eq(k).addClass('fy-disabled-bg');
                            }      

                        }
                    }
                });                
             }

             function getMonthValue(m){
                 settings.getMonth.call(this, m);
             }

             function getFyValue(y){
                 settings.getYear.call(this, y);
             }

             getDefaultFyDate();

             function getDefaultFyDate(){
                 settings.getDefaultDate.call(this, (dt.getMonth()+1));
             }

         });
     };
     
 })(jQuery);